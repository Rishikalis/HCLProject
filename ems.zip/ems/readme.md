How to Run Employee Management System in Python
Download and Extract the provided source code zip file.
Open your Terminal/Command Prompt window. (make sure to add "python" and "pip" in your environment variables)
Change the working directory to the extracted source code folder. i.e. cd C:\Users\Personal-23\Desktop\ems
Run the following commands:
pip install Django
python manage.py migrate
python manage.py runserver
Open a web browser and browse http://localhost:8000/ or http://127.0.0.1:8000/
admin:
Username: admin
Password: admin123

employee:
Username: 123123123
Password: welcome1234